package cat;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

// Implement the Calculator Remote Interface
public class CalculatorImpl extends UnicastRemoteObject implements Calculator {

    // Constructor
    protected CalculatorImpl() throws RemoteException {
        super();
    }

    // Implement the add method
    @Override
    public double add(double a, double b) throws RemoteException {
        return a + b;
    }

    // Implement the subtract method
    @Override
    public double subtract(double a, double b) throws RemoteException {
        return a - b;
    }

    // Implement the multiply method
    @Override
    public double multiply(double a, double b) throws RemoteException {
        return a * b;
    }

    // Implement the divide method
    @Override
    public double divide(double a, double b) throws RemoteException {
        if(b == 0) {
            throw new ArithmeticException("Division by zero is not allowed!");
        }
        return a / b;
    }

}
