package cat;

import java.rmi.Remote;
import java.rmi.RemoteException;

// Define the Remote Interface
public interface Calculator extends Remote {

    // Declare remote methods with RemoteException
    double add(double a, double b) throws RemoteException;
    double subtract(double a, double b) throws RemoteException;
    double multiply(double a, double b) throws RemoteException;
    double divide(double a, double b) throws RemoteException;

}
