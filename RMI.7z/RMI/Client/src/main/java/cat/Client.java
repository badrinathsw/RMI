package cat;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {
    public static void main(String[] args) throws RemoteException, NotBoundException, MalformedURLException {
        Registry registry = LocateRegistry.getRegistry();
        MessengerService server = (MessengerService) registry
                .lookup("MessengerService");
        String responseMessage = server.sendMessage("Client Message");
        //String expectedMessage = "Server Message";

        System.out.println("Response : "+ responseMessage);

        Calculator calculator = (Calculator) Naming.lookup("rmi://localhost/CalculatorService");

        // Invoke methods on the remote object
        double result = calculator.add(5, 3);
        System.out.println("Result of 5 + 3 = " + result);
    }
}
